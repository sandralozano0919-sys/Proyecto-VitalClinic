document.getElementById("btnAgendarCita").addEventListener("click", function () {
  alert("Funcionalidad para Agendar Cita próximamente.");
});

document.getElementById("btnConsultaVirtual").addEventListener("click", function () {
  alert("Funcionalidad para Consulta Virtual próximamente.");
});

document.getElementById("btn-agendar")?.addEventListener("click", () => {
  alert("Funcionalidad para Ingresar próximamente.");
});

document.getElementById("btn-registrarse")?.addEventListener("click", () => {
  alert("Funcionalidad para Registrarse próximamente.");
});
